from decimal import Decimal
from datetime import datetime
import json

class DecimalEncoder(json.JSONEncoder):
    def default(self, o):
        if isinstance(o, Decimal):
            if o % 1 != 0:
                return float(o)
            else:
                return int(o)
        elif isinstance(o, datetime):
            return o.strftime('%Y-%m-%d')
        return json.JSONEncoder.default(self, o)